These are input files for static overview documentation.

They will be copied into ../docsrc/ and other files in that directory
will be built automatically using ../../adddoxy/adddoxy.pl

